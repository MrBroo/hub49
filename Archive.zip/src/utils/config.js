export const POPPINS = { fontStyle: "normal", fontFamily: "Poppins" };
export const INTER = { fontStyle: "normal", fontFamily: "Inter" };
export const DM_SANS = { fontStyle: "normal", fontFamily: "DM Sans" };
